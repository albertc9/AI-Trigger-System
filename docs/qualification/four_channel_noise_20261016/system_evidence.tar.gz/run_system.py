from pathlib import Path
import hashlib,json,os,shutil,subprocess

base=Path('/home/work1/tmp/codex-noise-rate-20261016')
prior=Path('/home/work1/tmp/codex-channel-calibration-20261015-526a78d')
src=base/'src'
shutil.copytree(prior/'src',src,ignore=shutil.ignore_patterns('.Xil','__pycache__'))
tb=src/'tests/tb_native_system.sv'
text=tb.read_text()
assert text.count('forever #2.5 clk_cnn = ~clk_cnn;')==1
tb.write_text(text.replace('forever #2.5 clk_cnn = ~clk_cnn;',
                          'forever #(1000.0/195.0/2.0) clk_cnn = ~clk_cnn;'))
os.environ['PATH']=str(prior/'bin')+':'+os.environ['PATH']
reference=base/'stream_reference'
output=base/'system'
command=['python3',str(src/'scripts/run_native_sim.py'),'--reference',str(reference),
         '--output',str(output),'--vivado','/tools/Xilinx/Vivado/2022.2/bin/vivado',
         '--threshold','115']
with (base/'system.log').open('w') as log:
    subprocess.run(command,cwd=src,stdout=log,stderr=subprocess.STDOUT,check=True)
sim=output/'project/native_system.sim/sim_1/behav/xsim'
assert sim.is_dir(),sim
cases=[]
for word in [116,171]:
    log=base/f'threshold_{word}.log'
    command=['/tools/Xilinx/Vivado/2022.2/bin/xsim','tb_native_system_behav',
             '-testplusarg',f'REFERENCE={reference}','-testplusarg','WINDOWS=39',
             '-testplusarg',f'THRESHOLD={word:08x}','-runall','-log',str(log)]
    with (base/f'xsim_{word}.console.log').open('w') as f:
        subprocess.run(command,cwd=sim,stdout=f,stderr=subprocess.STDOUT,check=True)
    transcript=log.read_text()
    assert 'PASS native system windows=39 events=' in transcript and 'Fatal:' not in transcript
    cases.append({'threshold_word':word,'threshold':word/16,
                  'completion':[s for s in transcript.splitlines() if 'PASS native system' in s]})
for log in output.rglob('simulate.log'):
    for line in log.read_text().splitlines():
        if 'PASS native system' in line:
            cases.insert(0,{'threshold_word':115,'threshold':115/16,'completion':[line]})
summary={'adc_mhz':250,'cnn_mhz':195,'samples_per_adc_beat':4,
         'cases':cases,'testbench_change':'Only testbench CNN oscillator adjusted from 200 to 195 MHz; production RTL unchanged.',
         'testbench_sha256':hashlib.sha256(tb.read_bytes()).hexdigest()}
(base/'system_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))

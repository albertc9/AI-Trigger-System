# This script was generated automatically by bender.
set ROOT "/home/work1/tmp/codex-noise-rate-20261016/src"

add_files -norecurse -fileset [current_fileset] [list \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_dense_wide_stream_array_array_ap_fixed_1u_config12_Pipeline_DenseValues.v \
]

add_files -norecurse -fileset [current_fileset] [list \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_dense_wide_stream_array_array_ap_fixed_1u_config12_Pipeline_DenseValues_w12_rbkb.dat \
]

add_files -norecurse -fileset [current_fileset] [list \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_dense_wide_stream_array_array_ap_fixed_1u_config12_Pipeline_DenseValues_w12_rbkb.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_dense_wide_stream_array_array_ap_fixed_21_11_5_3_0_1u_config12_s.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_fifo_w480_d4_A.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_fifo_w864_d4_A.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_fifo_w912_d4_A.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_flow_control_loop_pipe.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_flow_control_loop_pipe_sequential_init.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_hls_deadlock_detection_unit.v \
]

add_files -norecurse -fileset [current_fileset] [list \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_hls_deadlock_detector.vh \
]

add_files -norecurse -fileset [current_fileset] [list \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_hls_deadlock_idx0_monitor.v \
]

add_files -norecurse -fileset [current_fileset] [list \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_hls_deadlock_kernel_monitor_top.vh \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_hls_deadlock_report_unit.vh \
]

add_files -norecurse -fileset [current_fileset] [list \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_mac_muladd_10s_6s_11s_16_1_1.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_mac_muladd_10s_6s_16s_17_1_1.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_mac_muladd_10s_6s_17s_17_1_1.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_mul_10s_6s_16_1_1.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_phara_pool_aligned_hybrid_p8_cl_array_array_array_array_config3_config5_s.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_regslice_both.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_relu_array_ap_fixed_48u_array_ap_ufixed_18_8_5_3_0_48u_relu_config8_s.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_scheduled_pool_array_array_ap_fixed_10_5_0_2_0_48u_config9_4u_s.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_shared_conv_array_array_ap_fixed_48u_config7_4u_ravel_matrix_conv2d_1_2u_s.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_sparsemux_17_3_10_1_1.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_start_for_dense_wide_stream_array_array_ap_fixed_21_11_5_3_0_1u_config12_U0.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_start_for_relu_array_ap_fixed_48u_array_ap_ufixed_18_8_5_3_0_48u_relu_config8dEe.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_start_for_scheduled_pool_array_array_ap_fixed_10_5_0_2_0_48u_config9_4u_U0.v \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/cnn_core/cnn_core_prj/solution1/impl/verilog/cnn_core_start_for_shared_conv_array_array_ap_fixed_48u_config7_4u_ravel_matrix_conv2dcud.v \
]

add_files -norecurse -fileset [current_fileset] [list \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Wrapper/hw/rtl/cnn_core_wrapper_top.v \
]

add_files -norecurse -fileset [current_fileset] [list \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/Hi-Lo-Trigger/hw/rtl/PRE_TRIGGER_PKG.vhd \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/Hi-Lo-Trigger/hw/rtl/Mult_to_bin.vhd \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/Hi-Lo-Trigger/hw/rtl/Pre_trigger_1ch.vhd \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/Hi-Lo-Trigger/hw/rtl/Pre_trigger.vhd \
]

add_files -norecurse -fileset [current_fileset] [list \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/Hi-Lo-Trigger/hw/sim/tb_pre_trigger_1ch.vhd \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/Hi-Lo-Trigger/hw/sim/tb_pre_trigger.vhd \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/Hi-Lo-Trigger/hw/sim/tb_pre_trigger_cosim.vhd \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/Hi-Lo-Trigger/hw/sim/tb_hilo_trigger.vhd \
]

add_files -norecurse -fileset [current_fileset] [list \
    /home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/Hi-Lo-Trigger/hw/constraints/pre_trigger.xdc \
]

add_files -norecurse -fileset [current_fileset] [list \
    $ROOT/HDL/rtl/CNN_INPUT_GAIN_PKG.vhd \
    $ROOT/HDL/rtl/CNN_INPUT_OFFSET_PKG.vhd \
    $ROOT/HDL/rtl/CNN_INPUT_CALIBRATION_PKG.vhd \
    $ROOT/HDL/rtl/AI_TRIGGER_PKG.vhd \
    $ROOT/HDL/rtl/RESET_SYNC.vhd \
    $ROOT/HDL/rtl/TRIGGER_MODE_CTRL.vhd \
    $ROOT/HDL/rtl/HOUSEKEEPING_TRIGGER_CTRL.vhd \
    $ROOT/HDL/rtl/HILO_INPUT_ADAPTER.vhd \
    $ROOT/HDL/rtl/HILO_TRIGGER_CTRL.vhd \
    $ROOT/HDL/rtl/GATED_CNN_READER.vhd \
    $ROOT/HDL/rtl/TRIGGER_DECISION.vhd \
    $ROOT/HDL/rtl/ADC_INPUT_CDC_FIFO.vhd \
    $ROOT/HDL/rtl/CHUNK_ID_CDC_FIFO.vhd \
    $ROOT/HDL/rtl/TRIGGER_CDC_FIFO.vhd \
    $ROOT/HDL/rtl/WAVEFORM_RING_BUFFER.vhd \
    $ROOT/HDL/rtl/RING_READ_ARBITER.vhd \
    $ROOT/HDL/rtl/EVENT_RECORDER.vhd \
    $ROOT/HDL/rtl/EVENT_CAPTURE_CTRL.vhd \
    $ROOT/HDL/rtl/EVENT_OUTPUT_FIFO.vhd \
    $ROOT/HDL/rtl/EVENT_CAPTURE_PATH.vhd \
    $ROOT/HDL/rtl/MULTIMODE_EVENT_PATH.vhd \
    $ROOT/HDL/rtl/ADC_CHUNK_DISTRIBUTOR.vhd \
    $ROOT/HDL/rtl/CNN_CORE_LANE.vhd \
    $ROOT/HDL/rtl/CNN_RESULT_ARBITER.vhd \
    $ROOT/HDL/rtl/AI_TRIGGER_CORE.vhd \
    $ROOT/HDL/rtl/AI_TRIGGER_TOP.vhd \
]

add_files -norecurse -fileset [current_fileset] [list \
    $ROOT/HDL/sim/AI_TRIGGER_TOP_TB_WRAP.vhd \
]

add_files -norecurse -fileset [current_fileset] [list \
    $ROOT/HDL/sim/tb_ai_trigger_top.sv \
]

set_property verilog_define [list \
    TARGET_FPGA \
    TARGET_SIMULATION \
    TARGET_SYNTHESIS \
    TARGET_VIVADO \
    TARGET_XILINX \
] [current_fileset]

set_property verilog_define [list \
    TARGET_FPGA \
    TARGET_SIMULATION \
    TARGET_SYNTHESIS \
    TARGET_VIVADO \
    TARGET_XILINX \
] [current_fileset -simset]


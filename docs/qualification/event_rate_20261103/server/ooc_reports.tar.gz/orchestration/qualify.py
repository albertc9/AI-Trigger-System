"""Event-rate server qualification: source parity, reference, system cases, OOC."""
from pathlib import Path
import json
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
src = root/'src'
base = root/'src-v41'
out = root/'qualification'
out.mkdir(exist_ok=True)
vivado = '/tools/Xilinx/Vivado/2023.2/bin/vivado'
xvlog = '/tools/Xilinx/Vivado/2023.2/bin/xvlog'
hls_include = '/tools/Xilinx/Vitis_HLS/2023.2/include'
deps = root/'deps'
os.environ['PATH'] = str(root/'bin') + ':' + os.environ['PATH']


def run(stage, cmd, cwd=src):
    with (root/(stage + '.log')).open('w') as log:
        log.write('COMMAND: ' + ' '.join(map(str, cmd)) + '\n')
        log.flush()
        result = subprocess.run(list(map(str, cmd)), cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
    (root/(stage + '.exit')).write_text(f'{result.returncode}\n')
    print(f'{stage}: exit {result.returncode}', flush=True)
    if result.returncode:
        raise SystemExit(f'{stage} failed: {result.returncode}')


def ooc(stage, repo, out_dir):
    tcl = root/(stage + '-runtime.tcl')
    settings = {
        'RUN_BUILD_REPO_ROOT': repo, 'RUN_BUILD_OUT_DIR': out_dir,
        'RUN_BUILD_PART': 'xcku5p-ffvb676-2-e', 'RUN_BUILD_TOP': 'AI_TRIGGER_TOP',
        'RUN_BUILD_IMPL': 1, 'RUN_BUILD_THREADS': 4, 'RUN_BUILD_MIN_SETUP_SLACK': 0.0,
    }
    tcl.write_text('set ::env(PATH) ' + str(root/'bin') + ':$::env(PATH)\n' +
                   '\n'.join(f'set ::{k} {{{v}}}' for k, v in settings.items()) +
                   '\nsource {' + str(repo/'scripts/vivado_ooc_build.tcl') + '}\nexit\n')
    run(stage, [vivado, '-mode', 'batch', '-source', tcl,
                '-log', root/(stage + '-vivado.log'), '-journal', root/(stage + '-vivado.jou')],
        cwd=repo)


sys.path.insert(0, str(src/'scripts'))
from source_manifest import capture  # noqa: E402

# 1. The server must compile exactly the sources resolved on the Mac.
capture(src, out, ['vivado', 'simulation'])
index = lambda d: {(v['package'], v['file']): v['sha256'] for v in d['files']}
local = json.loads((root/'local_source_manifest.json').read_text())
remote = json.loads((out/'source_manifest.json').read_text())
if index(local) != index(remote):
    raise SystemExit('local/server resolved source mismatch')
print('source parity: pass', flush=True)

# 2. Native reference; calibration is unchanged since v4.1, so data must match.
run('reference', ['python3', src/'scripts/build_native_reference.py',
                  '--core-root', deps/'CNN-Core-Generator',
                  '--npz', deps/'CNN-Core-Generator/models/amphp_oct_12/verification_data_v6_2cv_k5s3_f12_amphp.npz',
                  '--hls-include', hls_include, '--output', root/'reference'])
v41 = json.loads((root/'v41_reference.json').read_text())['files']
new = json.loads((root/'reference/reference.json').read_text())['files']
(out/'reference_parity.json').write_text(json.dumps(
    {'all_data_hashes_match_v41': v41 == new, 'files': new}, indent=2) + '\n')
if v41 != new:
    raise SystemExit('reference data differs from v4.1')
print('reference parity: pass', flush=True)

# 3. Nine real-XPM system cases (tb_native_system checks the event rate).
run('simulation', ['python3', src/'scripts/run_native_qualification.py',
                   '--reference', root/'reference', '--output', root/'simulation',
                   '--vivado', vivado])

# 4. Syntax check of the dataset-flow system testbench (not run by the cases).
svcheck = root/'svcheck'
svcheck.mkdir(exist_ok=True)
run('svcheck', [xvlog, '--sv', src/'HDL/sim/tb_ai_trigger_top.sv'], cwd=svcheck)

# 5. Routed OOC of v4.2 and of the unchanged v4.1 RTL with the same tool.
ooc('ooc', src, root/'ooc')
ooc('ooc-v41', base, root/'ooc-v41')

(root/'SUCCESS').write_text('source parity, reference parity, nine system cases, '
                            'SV syntax check and both routed OOC builds passed\n')
print('SUCCESS', flush=True)

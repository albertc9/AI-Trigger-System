set ::env(PATH) /home/work1/Works/ait-event-rate-20261103-e47ba83/bin:$::env(PATH)
set ::RUN_BUILD_REPO_ROOT {/home/work1/Works/ait-event-rate-20261103-e47ba83/src}
set ::RUN_BUILD_OUT_DIR {/home/work1/Works/ait-event-rate-20261103-e47ba83/ooc-ef510cf}
set ::RUN_BUILD_PART {xcku5p-ffvb676-2-e}
set ::RUN_BUILD_TOP {AI_TRIGGER_TOP}
set ::RUN_BUILD_IMPL {1}
set ::RUN_BUILD_THREADS {4}
set ::RUN_BUILD_MIN_SETUP_SLACK {0.0}
source {/home/work1/Works/ait-event-rate-20261103-e47ba83/src/scripts/vivado_ooc_build.tcl}
exit
